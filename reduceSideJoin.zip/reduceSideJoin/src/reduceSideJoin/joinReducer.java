package reduceSideJoin;

import java.io.IOException;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class joinReducer extends Reducer<Text, Text, Text, NullWritable>{
	public void reduce(Text rInpKey, Iterable<Text> rInpVal,Context con) throws IOException, InterruptedException{
		double amt=0.0;
		String name="";
		int tCount=0;
		String inputK=rInpKey.toString();
		String[] eachKey =inputK.split(":");
		
		for(Text each: rInpVal){
			String x = each.toString();
			String[] eachVal = x.split(":");
			
			if(eachVal[0].equals("amt")){
				tCount++;
				amt+=Double.parseDouble(eachVal[1]); 
			}
			if(eachVal[0].equals("name")){
				name= eachVal[1];
			}
		}
		Text rOutKey= new Text("User Id : " +eachKey[1] +" Customer : " +name +" Total Transaction : "+tCount +" Amount : " +amt);
		con.write(rOutKey, null);

		
		
	}

}
